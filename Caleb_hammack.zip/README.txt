Caleb Hammack 527007612

I was able to implement every part except extra credit as far as I know. Everything works as intended.

I also used one late day.