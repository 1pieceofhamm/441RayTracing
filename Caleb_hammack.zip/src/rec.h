#pragma once
#include <glm/glm.hpp>

struct rec {
	glm::vec3 ka, kd, ks, km, normal, point;
	float s;
};