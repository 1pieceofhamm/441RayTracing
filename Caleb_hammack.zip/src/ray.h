#pragma once
#include <glm/glm.hpp>

struct ray {
	glm::vec3 origin;
	glm::vec3 direction;
};